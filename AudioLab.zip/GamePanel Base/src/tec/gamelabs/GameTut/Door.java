package tec.gamelabs.GameTut;

public class Door {

}
